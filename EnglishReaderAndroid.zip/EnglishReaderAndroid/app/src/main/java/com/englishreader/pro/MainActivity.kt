@file:OptIn(ExperimentalMaterial3Api::class)

package com.englishreader.pro

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.Locale

const val SAMPLE = "Good morning! Learning English is easier when you listen every day. " +
    "Try changing the accent, slowing the speed, and repeating each sentence after the voice. " +
    "Practice makes progress."

val ACCENTS = listOf(
    "en-US" to "آمریکایی 🇺🇸", "en-GB" to "بریتانیایی 🇬🇧", "en-AU" to "استرالیایی 🇦🇺",
    "en-IN" to "هندی 🇮🇳", "en-CA" to "کانادایی 🇨🇦", "en-IE" to "ایرلندی 🇮🇪", "en-ZA" to "آفریقای جنوبی 🇿🇦"
)

private val LTR = TextStyle(textDirection = TextDirection.Ltr, textAlign = TextAlign.Left, fontSize = 17.sp, lineHeight = 28.sp)

data class HardWord(val word: String, val meaning: String, val example: String)

class MainActivity : ComponentActivity() {
    private lateinit var speaker: Speaker

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        speaker = Speaker(applicationContext)
        val shared = if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain")
            intent.getStringExtra(Intent.EXTRA_TEXT) else null
        val common = assets.open("common_words.txt").bufferedReader().readText()
            .split(Regex("\\s+")).filter { it.isNotBlank() }.toSet()
        setContent {
            AppTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MainScreen(speaker, common, shared)
                }
            }
        }
    }

    override fun onDestroy() {
        speaker.shutdown()
        super.onDestroy()
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) darkColorScheme(primary = Color(0xFF9A9AFF))
    else lightColorScheme(primary = Color(0xFF5B5BF0))
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun ChipRow(items: List<Pair<String, String>>, selected: String, onSel: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach { (k, l) -> FilterChip(selected = k == selected, onClick = { onSel(k) }, label = { Text(l) }) }
    }
}

@Composable
fun Section(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

fun wordAt(t: String, off: Int): String? {
    if (t.isEmpty()) return null
    var s = off.coerceIn(0, t.length - 1)
    if (!t[s].isLetter() && s > 0 && t[s - 1].isLetter()) s--
    if (!t[s].isLetter()) return null
    var a = s
    while (a > 0 && (t[a - 1].isLetter() || t[a - 1] == '\'')) a--
    var b = s
    while (b < t.length - 1 && (t[b + 1].isLetter() || t[b + 1] == '\'')) b++
    return t.substring(a, b + 1)
}

@Composable
fun MainScreen(sp: Speaker, common: Set<String>, shared: String?) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("erp", Context.MODE_PRIVATE) }
    val ml = remember { MlTranslator() }

    var text by remember { mutableStateOf(shared ?: prefs.getString("text", null) ?: SAMPLE) }
    var tab by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("") }
    var accent by remember { mutableStateOf(prefs.getString("accent", "en-US") ?: "en-US") }
    var target by remember { mutableStateOf(prefs.getString("target", "fa") ?: "fa") }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "claude-sonnet-5-5") ?: "claude-sonnet-5-5") }
    var useClaude by remember { mutableStateOf(prefs.getBoolean("useClaude", false)) }
    var rate by remember { mutableStateOf(1f) }
    var pitch by remember { mutableStateOf(1f) }
    var gap by remember { mutableStateOf(0f) }
    var rep by remember { mutableStateOf("1") }
    var loop by remember { mutableStateOf(false) }
    var vmenu by remember { mutableStateOf(false) }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    var words by remember { mutableStateOf<List<HardWord>>(emptyList()) }
    var level by remember { mutableStateOf("6") }
    var pairs by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    val readerScroll = rememberScrollState()

    fun put(k: String, v: String) = prefs.edit().putString(k, v).apply()
    fun copy(s: String) {
        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("erp", s))
        status = "📋 کپی شد"
    }

    LaunchedEffect(text) {
        sp.stop()
        sp.sentences = splitSentences(text)
        put("text", text)
    }
    LaunchedEffect(accent, sp.ready) { if (sp.ready) sp.setAccent(Locale.forLanguageTag(accent)) }
    LaunchedEffect(sp.curSentence) {
        val l = layout ?: return@LaunchedEffect
        val s = sp.sentences.getOrNull(sp.curSentence) ?: return@LaunchedEffect
        if (s.start < text.length) {
            val y = l.getLineTop(l.getLineForOffset(s.start)).toInt()
            readerScroll.animateScrollTo((y - 40).coerceAtLeast(0))
        }
    }

    suspend fun tr(texts: List<String>, asWords: Boolean = false): List<String> =
        if (useClaude && apiKey.isNotBlank()) Claude.translate(apiKey, model, texts, Langs.english(target), asWords)
        else {
            if (target in Langs.mlUnsupported) throw Exception("این زبان فقط با Claude پشتیبانی می‌شود (تب تنظیمات).")
            ml.translate(texts, target)
        }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            status = "⏳ در حال خواندن متن عکس…"
            try {
                val t = ocrImage(ctx, uri)
                if (t.isBlank()) status = "متنی در عکس پیدا نشد."
                else { text = t; status = "✅ متن استخراج شد. می‌توانید ویرایش و پخش کنید." }
            } catch (e: Exception) { status = "❌ ${e.message}" }
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.statusBarsPadding().navigationBarsPadding().imePadding()) {
            Text("🎧 English Reader Pro", fontWeight = FontWeight.Bold, fontSize = 20.sp,
                color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp))
            TabRow(selectedTabIndex = tab) {
                listOf("خواندن", "کلمات سخت", "ترجمه", "تنظیمات").forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, fontSize = 13.sp) })
                }
            }
            if (status.isNotBlank()) Text(status, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(12.dp, 6.dp), fontSize = 13.sp)
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (tab) {
                    0 -> {
                        OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(),
                            minLines = 4, maxLines = 8, textStyle = LTR,
                            placeholder = { Text("Paste or type English text…", style = LTR) })
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { pick.launch("image/*") }) { Text("🖼 عکس") }
                            OutlinedButton(onClick = {
                                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString()?.let { text = it }
                            }) { Text("📋 چسباندن") }
                            OutlinedButton(onClick = { text = "" }) { Text("پاک") }
                        }
                        Section("لهجه و صدا") {
                            ChipRow(ACCENTS, accent) { accent = it; put("accent", it) }
                            if (!sp.accentOk) Text("⚠️ این لهجه روی موتور TTS گوشی نصب نیست. در تنظیمات اندروید ← Text-to-speech داده صدای آن را دانلود کنید.",
                                color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                            Box {
                                OutlinedButton(onClick = { vmenu = true }) { Text("صدا: " + (sp.voiceName ?: "خودکار")) }
                                DropdownMenu(expanded = vmenu, onDismissRequest = { vmenu = false }) {
                                    DropdownMenuItem(text = { Text("خودکار") }, onClick = { sp.setVoice(null); vmenu = false })
                                    sp.voices.forEach { v ->
                                        DropdownMenuItem(text = { Text(v.name) }, onClick = { sp.setVoice(v.name); vmenu = false })
                                    }
                                }
                            }
                        }
                        Section("سرعت و تمرین") {
                            Text("سرعت: ${"%.2f".format(rate)}×")
                            Slider(value = rate, onValueChange = { rate = it; sp.rate = it }, onValueChangeFinished = { sp.restart() }, valueRange = 0.5f..2f)
                            Text("زیر و بمی: ${"%.1f".format(pitch)}")
                            Slider(value = pitch, onValueChange = { pitch = it; sp.pitch = it }, onValueChangeFinished = { sp.restart() }, valueRange = 0.5f..2f)
                            Text("مکث بین جمله‌ها: ${gap.toInt()} ثانیه")
                            Slider(value = gap, onValueChange = { gap = it; sp.gapMs = (it.toInt()) * 1000 }, valueRange = 0f..4f, steps = 3)
                            Text("تکرار هر جمله (Shadowing)")
                            ChipRow(listOf("1" to "۱", "2" to "۲", "3" to "۳", "5" to "۵"), rep) { rep = it; sp.repeat = it.toInt() }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(checked = loop, onCheckedChange = { loop = it; sp.loop = it })
                                Spacer(Modifier.padding(4.dp)); Text("تکرار کل متن")
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { sp.jump(sp.curSentence - 1) }) { Text("⏮") }
                            Button(onClick = { if (sp.playing) sp.pause() else if (sp.paused) sp.resume() else sp.play(0) }) {
                                Text(if (sp.playing) "⏸ مکث" else if (sp.paused) "▶ ادامه" else "▶ پخش")
                            }
                            OutlinedButton(onClick = { sp.stop() }) { Text("⏹") }
                            OutlinedButton(onClick = { sp.jump(sp.curSentence + 1) }) { Text("⏭") }
                        }
                        Button(modifier = Modifier.fillMaxWidth(), enabled = !sp.exporting && sp.sentences.isNotEmpty(), onClick = {
                            scope.launch {
                                status = "⏳ در حال ساخت فایل صوتی…"
                                val f = sp.exportWav()
                                status = if (f == null) "❌ ساخت فایل ناموفق بود (موتور TTS گوشی خروجی فایل را پشتیبانی نمی‌کند؟)"
                                else if (saveToDownloads(ctx, f)) "✅ ذخیره شد: Downloads/EnglishReader" else "❌ ذخیره نشد"
                            }
                        }) { Text("💾 ذخیره فایل صوتی (WAV)") }
                        if (sp.exporting) LinearProgressIndicator(progress = { sp.exportProgress }, modifier = Modifier.fillMaxWidth())

                        val hi = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                        val hw = MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
                        val annotated: AnnotatedString = buildAnnotatedString {
                            append(text)
                            sp.sentences.getOrNull(sp.curSentence)?.let { s ->
                                if (s.end <= text.length) addStyle(SpanStyle(background = hi), s.start, s.end)
                            }
                            sp.curWord?.let { r -> if (r.last < text.length) addStyle(SpanStyle(background = hw), r.first, r.last + 1) }
                        }
                        Text("📖 متن (لمس جمله = پخش از همان‌جا · لمس طولانی کلمه = تلفظ آهسته)", fontSize = 12.sp)
                        Card(Modifier.fillMaxWidth()) {
                            Text(
                                annotated, style = LTR.copy(color = MaterialTheme.colorScheme.onSurface),
                                onTextLayout = { layout = it },
                                modifier = Modifier.heightIn(max = 320.dp).verticalScroll(readerScroll).padding(12.dp)
                                    .pointerInput(sp.sentences) {
                                        detectTapGestures(
                                            onTap = { pos ->
                                                layout?.let { l ->
                                                    val off = l.getOffsetForPosition(pos)
                                                    val i = sp.sentences.indexOfFirst { off in it.start..it.end }
                                                    if (i >= 0) sp.play(i)
                                                }
                                            },
                                            onLongPress = { pos ->
                                                layout?.let { l -> wordAt(text, l.getOffsetForPosition(pos))?.let { sp.speakWord(it) } }
                                            }
                                        )
                                    }
                            )
                        }
                    }

                    1 -> {
                        Text("برنامه کلمه‌هایی را که در فهرست کلمات رایج نیستند پیدا می‌کند و معنی‌شان را به زبان انتخاب‌شده در تب «ترجمه» می‌آورد.", fontSize = 13.sp)
                        ChipRow(listOf("5" to "آسان‌تر", "6" to "متوسط", "8" to "فقط سخت"), level) { level = it }
                        Button(modifier = Modifier.fillMaxWidth(), onClick = {
                            scope.launch {
                                status = "⏳ در حال استخراج و ترجمه کلمات…"
                                try {
                                    val ws = HardWords.extract(text, common, level.toInt())
                                    if (ws.isEmpty()) { words = emptyList(); status = "کلمه سختی پیدا نشد." }
                                    else {
                                        val ms = tr(ws, asWords = true)
                                        words = ws.mapIndexed { i, w ->
                                            val ex = sp.sentences.firstOrNull { it.text.contains(w, ignoreCase = true) }?.text ?: ""
                                            HardWord(w, ms.getOrElse(i) { "" }, ex)
                                        }
                                        status = "✅ ${ws.size} کلمه پیدا شد"
                                    }
                                } catch (e: Exception) { status = "❌ ${e.message}" }
                            }
                        }) { Text("🔎 استخراج کلمات سخت") }
                        words.forEach { w ->
                            Card(Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(w.word, style = LTR.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary), modifier = Modifier.fillMaxWidth())
                                        Text(w.meaning, modifier = Modifier.fillMaxWidth(),
                                            style = if (target in Langs.rtl) TextStyle(fontSize = 16.sp) else LTR)
                                        if (w.example.isNotBlank()) Text(w.example, style = LTR.copy(fontSize = 13.sp, lineHeight = 18.sp), modifier = Modifier.fillMaxWidth())
                                    }
                                    TextButton(onClick = { sp.speakWord(w.word) }) { Text("🔊") }
                                }
                            }
                        }
                        if (words.isNotEmpty()) OutlinedButton(onClick = { copy(words.joinToString("\n") { "${it.word} — ${it.meaning}" }) }) { Text("📋 کپی همه") }
                    }

                    2 -> {
                        Text("زبان مقصد", fontWeight = FontWeight.Bold)
                        ChipRow(Langs.all.map { it.first to it.second }, target) { target = it; put("target", it) }
                        Text(
                            if (useClaude && apiKey.isNotBlank()) "موتور: Claude (دقت بالا)"
                            else "موتور: ML Kit آفلاین (بار اول مدل زبان ~۳۰MB دانلود می‌شود)",
                            fontSize = 12.sp
                        )
                        Button(modifier = Modifier.fillMaxWidth(), onClick = {
                            scope.launch {
                                status = "⏳ در حال ترجمه…"
                                try {
                                    val ss = sp.sentences.map { it.text }
                                    if (ss.isEmpty()) { status = "ابتدا متن وارد کنید."; return@launch }
                                    val res = tr(ss)
                                    pairs = ss.zip(res)
                                    status = "✅ ترجمه شد"
                                } catch (e: Exception) { status = "❌ ${e.message}" }
                            }
                        }) { Text("🌐 ترجمه جمله‌به‌جمله") }
                        pairs.forEach { (en, fa) ->
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(en, style = LTR.copy(fontSize = 15.sp, lineHeight = 22.sp), modifier = Modifier.fillMaxWidth())
                                    Text(fa, modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.primary,
                                        style = if (target in Langs.rtl) TextStyle(fontSize = 16.sp, lineHeight = 26.sp, textDirection = TextDirection.Rtl, textAlign = TextAlign.Right)
                                        else LTR.copy(fontSize = 16.sp))
                                }
                            }
                        }
                        if (pairs.isNotEmpty()) OutlinedButton(onClick = { copy(pairs.joinToString("\n\n") { it.first + "\n" + it.second }) }) { Text("📋 کپی ترجمه") }
                    }

                    else -> {
                        Section("ترجمه دقیق‌تر با Claude (اختیاری)") {
                            Text("ترجمه آفلاین ML Kit رایگان و سریع است ولی همیشه دقیق نیست. برای کیفیت بالاتر و همه زبان‌ها (مثل آذربایجانی) کلید API خودتان را وارد کنید. هزینه استفاده از API با حساب خودتان است و اینترنت لازم دارد.", fontSize = 12.sp)
                            OutlinedTextField(value = apiKey, onValueChange = { apiKey = it; put("key", it) }, label = { Text("Claude API Key") },
                                singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), textStyle = LTR)
                            OutlinedTextField(value = model, onValueChange = { model = it; put("model", it) }, label = { Text("Model") },
                                singleLine = true, modifier = Modifier.fillMaxWidth(), textStyle = LTR)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(checked = useClaude, onCheckedChange = { useClaude = it; prefs.edit().putBoolean("useClaude", it).apply() })
                                Spacer(Modifier.padding(4.dp)); Text("استفاده از Claude برای ترجمه و کلمات سخت")
                            }
                        }
                        Section("درباره") {
                            Text("• صدا: موتور Text-to-Speech گوشی (معمولاً Google). لهجه‌های بیشتر را از تنظیمات اندروید دانلود کنید.\n• OCR و ترجمه آفلاین: Google ML Kit.\n• می‌توانید از برنامه‌های دیگر، متن را با Share به این برنامه بفرستید.", fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}
