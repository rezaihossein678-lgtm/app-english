package com.englishreader.pro

import android.content.Context
import android.net.Uri
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Langs {
    // code, Persian name, English name
    val all = listOf(
        Triple("fa", "فارسی", "Persian"),
        Triple("ar", "عربی", "Arabic"),
        Triple("tr", "ترکی استانبولی", "Turkish"),
        Triple("az", "آذربایجانی (فقط Claude)", "Azerbaijani"),
        Triple("ru", "روسی", "Russian"),
        Triple("fr", "فرانسوی", "French"),
        Triple("de", "آلمانی", "German"),
        Triple("es", "اسپانیایی", "Spanish"),
        Triple("it", "ایتالیایی", "Italian"),
        Triple("pt", "پرتغالی", "Portuguese"),
        Triple("nl", "هلندی", "Dutch"),
        Triple("hi", "هندی", "Hindi"),
        Triple("ur", "اردو", "Urdu"),
        Triple("zh", "چینی", "Chinese"),
        Triple("ja", "ژاپنی", "Japanese"),
        Triple("ko", "کره‌ای", "Korean"),
    )
    val mlUnsupported = setOf("az")
    val rtl = setOf("fa", "ar", "ur")
    fun english(code: String) = all.firstOrNull { it.first == code }?.third ?: "Persian"
}

/** On-device OCR (Google ML Kit, Latin script). */
suspend fun ocrImage(ctx: Context, uri: Uri): String {
    val img = InputImage.fromFilePath(ctx, uri)
    val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    try {
        val res = rec.process(img).await()
        return res.textBlocks.joinToString("\n") { b -> b.lines.joinToString(" ") { it.text } }
    } finally {
        rec.close()
    }
}

/** Offline translation (ML Kit). The language model (~30 MB) downloads once. */
class MlTranslator {
    private val cache = HashMap<String, Translator>()

    suspend fun translate(texts: List<String>, target: String): List<String> {
        val tr = cache.getOrPut(target) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.ENGLISH)
                    .setTargetLanguage(target)
                    .build()
            )
        }
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
        return texts.map { tr.translate(it).await() }
    }
}

/** High-accuracy translation through the Claude API (needs the user's API key + internet). */
object Claude {
    suspend fun translate(
        key: String, model: String, texts: List<String>, lang: String, words: Boolean = false
    ): List<String> = withContext(Dispatchers.IO) {
        val out = ArrayList<String>()
        val re = Regex("""^\s*(\d+)[.)]\s*(.*)$""")
        for (chunk in texts.chunked(40)) {
            val rules = if (words)
                "These are individual English words (possibly from a text for learners). For each, give the most common 1-3 short meanings in $lang, separated by commas."
            else
                "Translate each English sentence into natural, accurate $lang. Preserve meaning, tone and register."
            val prompt = "You are a professional translator. $rules\n" +
                "Output exactly one line per input line, keeping the same numbering like '1. ...'. No explanations.\n\n" +
                chunk.mapIndexed { i, t -> "${i + 1}. ${t.replace("\n", " ")}" }.joinToString("\n")
            val resp = call(key, model, prompt)
            val map = HashMap<Int, String>()
            resp.lines().forEach { l -> re.find(l)?.let { m -> map[m.groupValues[1].toInt()] = m.groupValues[2].trim() } }
            chunk.indices.forEach { i -> out += map[i + 1] ?: "" }
        }
        out
    }

    private fun call(key: String, model: String, prompt: String): String {
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 4000)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        val conn = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 120000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", key)
            setRequestProperty("anthropic-version", "2023-06-01")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val txt = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader(Charsets.UTF_8)?.readText().orEmpty()
        if (code !in 200..299) throw Exception("Claude API ($code): ${txt.take(160)}")
        return JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
    }
}

/** Heuristic "hard word" finder: rare words = not in the bundled common-word list. */
object HardWords {
    private val tokenRe = Regex("[A-Za-z][A-Za-z'’-]*")
    private val suffixes = listOf("ies", "es", "s", "ed", "d", "ing", "ly", "er", "est")

    private fun known(w: String, common: Set<String>): Boolean {
        if (w in common) return true
        for (suf in suffixes) {
            if (!w.endsWith(suf) || w.length - suf.length < 3) continue
            val b = w.dropLast(suf.length)
            if (b in common || b + "e" in common) return true
            if (suf == "ies" && b + "y" in common) return true
            if (b.length > 2 && b[b.length - 1] == b[b.length - 2] && b.dropLast(1) in common) return true
        }
        return false
    }

    fun extract(text: String, common: Set<String>, minLen: Int, max: Int = 60): List<String> {
        val seen = LinkedHashSet<String>()
        for (m in tokenRe.findAll(text)) {
            val w = m.value.trim('-')
            if (w.length < minLen || w.contains('\'') || w.contains('’')) continue
            if (w.all { it.isUpperCase() }) continue
            val prev = text.substring(0, m.range.first).trimEnd().lastOrNull()
            val startsSentence = prev == null || prev in ".!?\"”’"
            if (w[0].isUpperCase() && !startsSentence) continue
            val l = w.lowercase()
            if (known(l, common)) continue
            seen += l
            if (seen.size >= max) break
        }
        return seen.toList()
    }
}
