package com.englishreader.pro

import android.content.ContentValues
import android.content.Context
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

data class Sentence(val start: Int, val end: Int, val text: String)

private val SENT_RE = Regex("""[^.!?\n]+[.!?]*["”’)]*""")

fun splitSentences(t: String): List<Sentence> =
    SENT_RE.findAll(t).mapNotNull { m ->
        val raw = m.value
        val tr = raw.trim()
        if (tr.none { it.isLetterOrDigit() }) null
        else {
            val s = m.range.first + (raw.length - raw.trimStart().length)
            Sentence(s, s + tr.length, tr)
        }
    }.toList()

class Speaker(private val ctx: Context) {
    var ready by mutableStateOf(false)
    var accentOk by mutableStateOf(true)
    var playing by mutableStateOf(false)
    var paused by mutableStateOf(false)
    var exporting by mutableStateOf(false)
    var exportProgress by mutableFloatStateOf(0f)
    var curSentence by mutableIntStateOf(-1)
    var curWord by mutableStateOf<IntRange?>(null)
    var sentences by mutableStateOf<List<Sentence>>(emptyList())
    var voices by mutableStateOf<List<Voice>>(emptyList())
    var voiceName by mutableStateOf<String?>(null)

    var rate = 1f
    var pitch = 1f
    var gapMs = 0
    var repeat = 1
    var loop = false

    private var tts: TextToSpeech? = null
    private var locale: Locale = Locale.US
    private var session = 0
    private var lastId = ""
    private val main = Handler(Looper.getMainLooper())
    private val waiters = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            val p = utteranceId?.split('_') ?: return
            if (p.size < 3 || p[0] != "p$session") return
            p[1].toIntOrNull()?.let { curSentence = it; curWord = null }
        }

        override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
            val p = utteranceId?.split('_') ?: return
            if (p.size < 3 || p[0] != "p$session") return
            val i = p[1].toIntOrNull() ?: return
            val s = sentences.getOrNull(i) ?: return
            curWord = (s.start + start) until (s.start + end)
        }

        override fun onDone(utteranceId: String?) {
            val id = utteranceId ?: return
            waiters.remove(id)?.complete(true)
            if (id == lastId) {
                main.post {
                    if (loop && playing) play(0)
                    else { playing = false; curSentence = -1; curWord = null }
                }
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            utteranceId?.let { waiters.remove(it)?.complete(false) }
        }

        override fun onError(utteranceId: String?, errorCode: Int) {
            utteranceId?.let { waiters.remove(it)?.complete(false) }
        }
    }

    init {
        tts = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.setOnUtteranceProgressListener(listener)
                ready = true
            }
        }
    }

    fun setAccent(l: Locale) {
        val t = tts ?: return
        locale = l
        voiceName = null
        val r = t.setLanguage(l)
        accentOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        voices = try {
            (t.voices ?: emptySet<Voice>())
                .filter {
                    it.locale.language == l.language && it.locale.country == l.country &&
                        it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true
                }
                .sortedBy { it.name }
        } catch (e: Exception) {
            emptyList()
        }
        restart()
    }

    fun setVoice(name: String?) {
        voiceName = name
        restart()
    }

    private fun applyVoice() {
        val t = tts ?: return
        t.setLanguage(locale)
        voiceName?.let { n -> t.voices?.firstOrNull { it.name == n }?.let { t.setVoice(it) } }
        t.setSpeechRate(rate)
        t.setPitch(pitch)
    }

    fun play(from: Int = 0) {
        val t = tts ?: return
        if (sentences.isEmpty() || from !in sentences.indices) return
        t.stop()
        session++
        lastId = ""
        val s = session
        applyVoice()
        playing = true; paused = false; curSentence = from; curWord = null
        var last = ""
        for (i in from until sentences.size) {
            for (k in 0 until repeat) {
                val id = "p${s}_${i}_$k"
                t.speak(sentences[i].text.take(3900), TextToSpeech.QUEUE_ADD, null, id)
                last = id
                if (gapMs > 0) {
                    val gid = "g${s}_${i}_$k"
                    t.playSilentUtterance(gapMs.toLong(), TextToSpeech.QUEUE_ADD, gid)
                    last = gid
                }
            }
        }
        lastId = last
    }

    fun pause() {
        if (!playing) return
        tts?.stop(); session++; lastId = ""
        playing = false; paused = true
    }

    fun resume() = play(curSentence.coerceAtLeast(0))

    fun stop() {
        tts?.stop(); session++; lastId = ""
        playing = false; paused = false; curSentence = -1; curWord = null
    }

    fun restart() { if (playing) play(curSentence.coerceAtLeast(0)) }

    fun jump(i: Int) {
        if (sentences.isEmpty()) return
        play(i.coerceIn(0, sentences.lastIndex))
    }

    fun speakWord(w: String) {
        val t = tts ?: return
        t.stop(); session++; lastId = ""
        playing = false; paused = false
        applyVoice()
        t.setSpeechRate(0.6f)
        t.speak(w, TextToSpeech.QUEUE_FLUSH, null, "w${System.nanoTime()}")
    }

    /** Synthesizes every sentence to a WAV file and merges them. Returns null on failure. */
    suspend fun exportWav(): File? = withContext(Dispatchers.IO) {
        val t = tts ?: return@withContext null
        if (sentences.isEmpty()) return@withContext null
        stop()
        applyVoice()
        exporting = true; exportProgress = 0f
        try {
            val parts = ArrayList<File>()
            for ((i, s) in sentences.withIndex()) {
                val f = File(ctx.cacheDir, "seg_$i.wav")
                val id = "f${System.nanoTime()}_$i"
                val d = CompletableDeferred<Boolean>()
                waiters[id] = d
                val r = t.synthesizeToFile(s.text.take(3900), Bundle(), f, id)
                if (r != TextToSpeech.SUCCESS) return@withContext null
                if (!d.await()) return@withContext null
                parts += f
                exportProgress = (i + 1f) / sentences.size
            }
            val out = File(ctx.cacheDir, "english-speech.wav")
            mergeWavs(parts, out)
            parts.forEach { it.delete() }
            out
        } catch (e: Exception) {
            null
        } finally {
            exporting = false
        }
    }

    fun shutdown() { tts?.stop(); tts?.shutdown() }
}

private fun le32(b: ByteArray, o: Int): Int =
    (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or
        ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)

private fun putLe32(b: ByteArray, o: Int, v: Int) {
    b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte(); b[o + 2] = (v shr 16).toByte(); b[o + 3] = (v shr 24).toByte()
}

/** Index of the "data" chunk id inside a WAV byte array, or -1. */
private fun findDataChunk(b: ByteArray): Int {
    var pos = 12
    while (pos + 8 <= b.size) {
        val id = String(b, pos, 4, Charsets.ISO_8859_1)
        if (id == "data") return pos
        val sz = le32(b, pos + 4)
        if (sz < 0) return -1
        pos += 8 + sz + (sz and 1)
    }
    return -1
}

fun mergeWavs(files: List<File>, out: File) {
    var header: ByteArray? = null
    val pcm = ByteArrayOutputStream()
    for (f in files) {
        val b = f.readBytes()
        val di = findDataChunk(b)
        if (di < 0) continue
        val start = di + 8
        var size = le32(b, di + 4)
        if (size <= 0 || start + size > b.size) size = b.size - start
        if (header == null) header = b.copyOfRange(0, start)
        pcm.write(b, start, size)
    }
    val h = header ?: throw IllegalStateException("no audio")
    val data = pcm.toByteArray()
    putLe32(h, 4, h.size - 8 + data.size)
    putLe32(h, h.size - 4, data.size)
    out.writeBytes(h + data)
}

fun saveToDownloads(ctx: Context, file: File): Boolean {
    val name = "english-speech-${System.currentTimeMillis() / 1000}.wav"
    val v = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, name)
        put(MediaStore.Downloads.MIME_TYPE, "audio/wav")
        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/EnglishReader")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return false
    ctx.contentResolver.openOutputStream(uri)?.use { o -> file.inputStream().use { it.copyTo(o) } } ?: return false
    return true
}
